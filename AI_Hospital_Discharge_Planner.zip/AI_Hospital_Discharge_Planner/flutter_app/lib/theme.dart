import 'package:flutter/material.dart';

// ── Brand colours (from eHospital Figma) ─────────────────────────────────────
const kPrimary     = Color(0xFF1E4ED8);
const kPrimaryL    = Color(0xFF2563EB);
const kPrimaryBg   = Color(0xFFEFF6FF);
const kPrimaryPale = Color(0xFFDBEAFE);
const kBg          = Color(0xFFF8FAFC);
const kCard        = Colors.white;
const kText        = Color(0xFF0F172A);
const kText2       = Color(0xFF334155);
const kMuted       = Color(0xFF64748B);
const kMuted2      = Color(0xFF94A3B8);
const kBorder      = Color(0xFFE2E8F0);
const kBorder2     = Color(0xFFCBD5E1);

const kGreen       = Color(0xFF16A34A);
const kGreenBg     = Color(0xFFF0FDF4);
const kGreenPale   = Color(0xFFDCFCE7);
const kYellow      = Color(0xFFCA8A04);
const kYellowBg    = Color(0xFFFEFCE8);
const kYellowPale  = Color(0xFFFEF9C3);
const kRed         = Color(0xFFDC2626);
const kRedBg       = Color(0xFFFFF5F5);
const kRedPale     = Color(0xFFFEE2E2);

const kSidebarW    = 220.0;

// ── Backend URL ───────────────────────────────────────────────────────────────
const kBackendUrl  = 'http://localhost:8000';

// ── Shared text styles ────────────────────────────────────────────────────────
const kFontFamily  = 'Inter';

TextStyle ts(double size, FontWeight w, Color c) =>
    TextStyle(fontFamily: kFontFamily, fontSize: size, fontWeight: w, color: c);

// ── Level helpers ─────────────────────────────────────────────────────────────
Color levelColor(String? level) {
  switch (level) {
    case 'HIGH':     return kRed;
    case 'MODERATE': return kYellow;
    default:         return kGreen;
  }
}

Color levelBg(String? level) {
  switch (level) {
    case 'HIGH':     return kRedPale;
    case 'MODERATE': return kYellowPale;
    default:         return kGreenPale;
  }
}

String levelEmoji(String? level) {
  switch (level) {
    case 'HIGH':     return '🔴';
    case 'MODERATE': return '🟡';
    default:         return '🟢';
  }
}
