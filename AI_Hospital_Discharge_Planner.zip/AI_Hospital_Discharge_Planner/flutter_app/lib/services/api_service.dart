import 'dart:convert';
import 'package:http/http.dart' as http;
import '../theme.dart';

class ApiService {
  static const _h = {'Content-Type': 'application/json'};
  static const _t = Duration(seconds: 20);
  static const _tLong = Duration(seconds: 90);

  static Future<Map<String, dynamic>> login(String email, String password) async {
    final r = await http.post(Uri.parse('$kBackendUrl/api/login'),
        headers: _h, body: jsonEncode({'email': email, 'password': password})).timeout(_t);
    final d = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode != 200) throw Exception(d['error'] ?? 'Login failed');
    return d;
  }

  static Future<List<dynamic>> getPatients(dynamic doctorId) async {
    final r = await http.post(Uri.parse('$kBackendUrl/api/patients'),
        headers: _h, body: jsonEncode({'doctorId': doctorId})).timeout(_t);
    final d = jsonDecode(r.body);
    return d is List ? d : [];
  }

  static Future<Map<String, dynamic>> getPatientData(dynamic patientId, dynamic doctorId) async {
    final r = await http.post(Uri.parse('$kBackendUrl/api/patient-data'),
        headers: _h, body: jsonEncode({'patientId': patientId, 'doctorId': doctorId})).timeout(_t);
    final d = jsonDecode(r.body);
    return d is Map<String, dynamic> ? d : {};
  }

  static Future<Map<String, dynamic>> assess(Map<String, dynamic> patient, String section) async {
    final r = await http.post(Uri.parse('$kBackendUrl/api/assess'),
        headers: _h, body: jsonEncode({'patient': patient, 'section': section})).timeout(_tLong);
    final d = jsonDecode(r.body);
    if (r.statusCode != 200) throw Exception((d as Map)['error'] ?? 'Agent error');
    return d is Map<String, dynamic> ? d : {};
  }
}
