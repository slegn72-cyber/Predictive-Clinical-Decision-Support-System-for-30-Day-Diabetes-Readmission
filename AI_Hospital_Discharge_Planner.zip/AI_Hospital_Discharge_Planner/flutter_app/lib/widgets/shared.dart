import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import '../theme.dart';

// ── Card wrapper ──────────────────────────────────────────────────────────────
class EhCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  const EhCard({super.key, required this.child, this.padding});

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    margin: const EdgeInsets.only(bottom: 16),
    padding: padding ?? const EdgeInsets.all(20),
    decoration: BoxDecoration(
      color: kCard,
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: kBorder),
      boxShadow: [BoxShadow(color: Colors.black.withOpacity(.05), blurRadius: 4, offset: const Offset(0, 2))],
    ),
    child: child,
  );
}

// ── Section title ─────────────────────────────────────────────────────────────
class CardTitle extends StatelessWidget {
  final String text;
  final String? subtitle;
  final Widget? trailing;
  const CardTitle(this.text, {super.key, this.subtitle, this.trailing});

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(children: [
        Text(text, style: ts(14, FontWeight.w600, kText)),
        if (trailing != null) ...[const Spacer(), trailing!],
      ]),
      if (subtitle != null) ...[
        const SizedBox(height: 2),
        Text(subtitle!, style: ts(11.5, FontWeight.w400, kMuted)),
      ],
    ],
  );
}

// ── Primary button ────────────────────────────────────────────────────────────
class EhButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final bool loading;
  final bool fullWidth;
  final Color? bg;
  final Color? fg;
  final double fontSize;
  const EhButton(this.label, {super.key, this.onTap, this.loading = false,
    this.fullWidth = false, this.bg, this.fg, this.fontSize = 13});

  @override
  Widget build(BuildContext context) {
    final btn = ElevatedButton(
      onPressed: loading ? null : onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: bg ?? kPrimary,
        foregroundColor: fg ?? Colors.white,
        disabledBackgroundColor: (bg ?? kPrimary).withOpacity(.6),
        elevation: 0,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 11),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(7)),
        textStyle: TextStyle(fontFamily: kFontFamily, fontSize: fontSize, fontWeight: FontWeight.w600),
      ),
      child: loading
          ? const SizedBox(width: 16, height: 16,
              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
          : Text(label),
    );
    return fullWidth ? SizedBox(width: double.infinity, child: btn) : btn;
  }
}

// ── Outline button ────────────────────────────────────────────────────────────
class EhOutlineButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  const EhOutlineButton(this.label, {super.key, this.onTap});

  @override
  Widget build(BuildContext context) => OutlinedButton(
    onPressed: onTap,
    style: OutlinedButton.styleFrom(
      foregroundColor: kPrimary,
      side: const BorderSide(color: kPrimary),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(7)),
      textStyle: const TextStyle(fontFamily: kFontFamily, fontSize: 13, fontWeight: FontWeight.w600),
    ),
    child: Text(label),
  );
}

// ── Risk pill ─────────────────────────────────────────────────────────────────
class RiskPill extends StatelessWidget {
  final String level;
  final bool large;
  const RiskPill(this.level, {super.key, this.large = false});

  @override
  Widget build(BuildContext context) => Container(
    padding: EdgeInsets.symmetric(horizontal: large ? 16 : 10, vertical: large ? 6 : 4),
    decoration: BoxDecoration(color: levelBg(level), borderRadius: BorderRadius.circular(999)),
    child: Text('${levelEmoji(level)} $level RISK',
      style: ts(large ? 13 : 11, FontWeight.w700, levelColor(level))),
  );
}

// ── Info chip ─────────────────────────────────────────────────────────────────
class InfoChip extends StatelessWidget {
  final String text;
  final Color? bg;
  final Color? fg;
  const InfoChip(this.text, {super.key, this.bg, this.fg});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(color: bg ?? kPrimaryBg, borderRadius: BorderRadius.circular(999)),
    child: Text(text, style: ts(11.5, FontWeight.w600, fg ?? kPrimaryL)),
  );
}

// ── Alert banner ──────────────────────────────────────────────────────────────
class AlertBanner extends StatelessWidget {
  final String text;
  final bool isError;
  const AlertBanner(this.text, {super.key, this.isError = false});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
    margin: const EdgeInsets.only(bottom: 12),
    decoration: BoxDecoration(
      color: isError ? kRedBg : kPrimaryBg,
      borderRadius: BorderRadius.circular(7),
      border: Border(left: BorderSide(color: isError ? kRed : kPrimary, width: 3)),
    ),
    child: Text(text, style: ts(12.5, FontWeight.w400, isError ? kRed : kPrimary)),
  );
}

// ── Section divider label ─────────────────────────────────────────────────────
class SectionLabel extends StatelessWidget {
  final String text;
  const SectionLabel(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 10, bottom: 6),
    child: Text(text.toUpperCase(),
      style: ts(10.5, FontWeight.w700, kMuted).copyWith(letterSpacing: .7)),
  );
}

// ── LACE component bar ────────────────────────────────────────────────────────
class LaceBar extends StatelessWidget {
  final String letter, label, note;
  final int score, max;
  final Color color;
  const LaceBar({super.key, required this.letter, required this.label,
    required this.note, required this.score, required this.max, required this.color});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(children: [
      Container(width: 26, height: 26,
        decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(6)),
        child: Center(child: Text(letter, style: ts(12, FontWeight.w800, color)))),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: ts(12.5, FontWeight.w600, kText)),
        const SizedBox(height: 3),
        ClipRRect(borderRadius: BorderRadius.circular(999),
          child: LinearProgressIndicator(value: score / max,
            backgroundColor: kBorder, color: color, minHeight: 4)),
        const SizedBox(height: 2),
        Text(note, style: ts(10.5, FontWeight.w400, kMuted)),
      ])),
      const SizedBox(width: 10),
      Text('$score/$max', style: ts(12, FontWeight.w700, color)),
    ]),
  );
}

// ── AI output box ─────────────────────────────────────────────────────────────
class AiOutputBox extends StatelessWidget {
  final String text;
  const AiOutputBox(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: kBorder),
    ),
    padding: const EdgeInsets.all(20),
    child: MarkdownBody(
      data: text,
      styleSheet: MarkdownStyleSheet(
        h1: ts(16, FontWeight.w700, kText),
        h2: ts(15, FontWeight.w700, kText),
        h3: ts(14, FontWeight.w700, kPrimary),
        p: ts(13, FontWeight.w400, kText2).copyWith(height: 1.8),
        strong: ts(13, FontWeight.w700, kText),
        em: ts(13, FontWeight.w400, kMuted).copyWith(fontStyle: FontStyle.italic),
        listBullet: ts(13, FontWeight.w400, kText2),
        blockquoteDecoration: BoxDecoration(
          color: kPrimaryBg,
          border: const Border(left: BorderSide(color: kPrimaryL, width: 3)),
          borderRadius: BorderRadius.circular(4),
        ),
        blockquotePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        horizontalRuleDecoration: const BoxDecoration(
          border: Border(top: BorderSide(color: kBorder)),
        ),
        h2Padding: const EdgeInsets.only(top: 16, bottom: 6),
        h3Padding: const EdgeInsets.only(top: 12, bottom: 4),
        listIndent: 20,
      ),
      selectable: true,
    ),
  );
}

// ── Empty state ───────────────────────────────────────────────────────────────
class EmptyState extends StatelessWidget {
  final String icon, text;
  const EmptyState({super.key, required this.icon, required this.text});
  @override
  Widget build(BuildContext context) => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Text(icon, style: const TextStyle(fontSize: 38)),
      const SizedBox(height: 10),
      Text(text, style: ts(13, FontWeight.w400, kMuted), textAlign: TextAlign.center),
    ]),
  );
}
