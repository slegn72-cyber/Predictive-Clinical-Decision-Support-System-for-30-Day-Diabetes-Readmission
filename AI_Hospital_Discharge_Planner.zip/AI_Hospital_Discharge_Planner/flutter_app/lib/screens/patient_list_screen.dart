import 'package:flutter/material.dart';
import '../theme.dart';
import '../widgets/shared.dart';
import '../services/api_service.dart';
import 'assessment_screen.dart';

/// Drop this widget into the Doctor Dashboard content switcher.
/// Requires [doctor] map with an 'id' field from the eHospital login response.
///
/// Example usage in DoctorDashboardScreen._buildContent():
///   } else if (selectedIndex == 8) {
///     return DischargePatientListScreen(doctor: widget.doctor);
///   }
class DischargePatientListScreen extends StatefulWidget {
  final Map<String, dynamic> doctor;
  const DischargePatientListScreen({super.key, required this.doctor});

  @override
  State<DischargePatientListScreen> createState() => _DischargePatientListScreenState();
}

class _DischargePatientListScreenState extends State<DischargePatientListScreen> {
  List<dynamic> _allPats = [];
  List<dynamic> _filtered = [];
  bool _loading = true;
  String? _error;
  Map<String, dynamic>? _selected;
  final _searchCtrl = TextEditingController();
  String _diagnosis = 'Heart Failure';
  final _dateCtrl = TextEditingController();
  int _page = 1;
  static const _perPage = 10;

  static const _diagnoses = [
    'Heart Failure','COPD Exacerbation','Pneumonia','Sepsis','Acute MI',
    'Diabetes Decompensation','Stroke','Hip Fracture','Kidney Disease',
    'Liver Disease','Cancer','Other',
  ];

  @override
  void initState() {
    super.initState();
    final n = DateTime.now();
    _dateCtrl.text = '${n.year}-${n.month.toString().padLeft(2,'0')}-${n.day.toString().padLeft(2,'0')}';
    _searchCtrl.addListener(_filter);
    _loadPatients();
  }

  @override
  void dispose() { _searchCtrl.dispose(); _dateCtrl.dispose(); super.dispose(); }

  Future<void> _loadPatients() async {
    setState(() { _loading = true; _error = null; });
    try {
      final did = widget.doctor['id'] ?? widget.doctor['doctor_id'] ?? widget.doctor['doctorId'];
      final d = await ApiService.getPatients(did);
      setState(() { _allPats = d; _filtered = d; _loading = false; });
    } catch (e) {
      setState(() { _error = e.toString().replaceAll('Exception: ', ''); _loading = false; });
    }
  }

  void _filter() {
    final q = _searchCtrl.text.toLowerCase();
    setState(() {
      _page = 1;
      _filtered = q.isEmpty ? _allPats : _allPats.where((p) {
        final name = '${p['FName']??p['firstName']??''} ${p['LName']??p['lastName']??''}'.toLowerCase();
        return name.contains(q) || '${p['id']??p['patientId']??''}'.contains(q);
      }).toList();
    });
  }

  String _name(Map p) {
    final n = '${p['FName']??p['firstName']??''} ${p['LName']??p['lastName']??''}'.trim();
    return n.isEmpty ? 'Unknown' : n;
  }

  List<dynamic> get _paged {
    final start = (_page - 1) * _perPage;
    return _filtered.skip(start).take(_perPage).toList();
  }
  int get _totalPages => (_filtered.length / _perPage).ceil().clamp(1, 999);

  Future<void> _goAssess() async {
    if (_selected == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a patient first.')));
      return;
    }
    showDialog(context: context, barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator(color: kPrimary)));

    try {
      final id  = _selected!['id'] ?? _selected!['patientId'];
      final did = widget.doctor['id'] ?? widget.doctor['doctor_id'] ?? 58;
      final data = await ApiService.getPatientData(id, did);
      if (!mounted) return;
      Navigator.pop(context);
      Navigator.push(context, MaterialPageRoute(builder: (_) => DischargeAssessmentScreen(
        patient: _selected!,
        details: Map<String, dynamic>.from(data['details'] ?? {}),
        visits: List<dynamic>.from(data['visits'] ?? []),
        prescriptions: List<dynamic>.from(data['prescriptions'] ?? []),
        bloodtests: List<dynamic>.from(data['bloodtests'] ?? []),
        diagnosis: _diagnosis,
        dischargeDate: _dateCtrl.text,
      )));
    } catch (e) {
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: kBg,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _buildBanner(),
          _buildPatientCard(),
        ]),
      ),
    );
  }

  Widget _buildBanner() => Container(
    width: double.infinity,
    margin: const EdgeInsets.only(bottom: 20),
    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFF1E40AF), Color(0xFF2563EB), Color(0xFF3B82F6)]),
      borderRadius: BorderRadius.circular(10)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('🏥  Discharge Risk Assessment & Planning',
        style: ts(18, FontWeight.w800, Colors.white)),
      const SizedBox(height: 3),
      Text('Select a patient to begin AI-powered risk assessment using LACE Index · Lab Interpretation · Social Risk',
        style: ts(12.5, FontWeight.w400, Colors.white.withOpacity(.85))),
    ]),
  );

  Widget _buildPatientCard() => EhCard(
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const CardTitle('Patient List'),
          Text('${_filtered.length} patient${_filtered.length!=1?'s':''} authorized',
            style: ts(11.5, FontWeight.w400, kMuted)),
        ]),
        const Spacer(),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Diagnosis at Discharge', style: ts(11.5, FontWeight.w600, kText2)),
          const SizedBox(height: 5),
          Container(
            height: 38, padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(border: Border.all(color: kBorder2),
              borderRadius: BorderRadius.circular(7), color: kCard),
            child: DropdownButtonHideUnderline(child: DropdownButton<String>(
              value: _diagnosis, isDense: true,
              style: ts(13, FontWeight.w400, kText),
              items: _diagnoses.map((d) => DropdownMenuItem(value: d, child: Text(d))).toList(),
              onChanged: (v) { if (v != null) setState(() => _diagnosis = v); },
            )),
          ),
        ]),
        const SizedBox(width: 12),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Discharge Date', style: ts(11.5, FontWeight.w600, kText2)),
          const SizedBox(height: 5),
          SizedBox(width: 140, height: 38,
            child: TextField(controller: _dateCtrl, style: ts(13, FontWeight.w400, kText),
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(7),
                  borderSide: const BorderSide(color: kBorder2)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(7),
                  borderSide: const BorderSide(color: kBorder2)),
              ))),
        ]),
      ]),
      const SizedBox(height: 14),

      Row(children: [
        Expanded(child: SizedBox(height: 38,
          child: TextField(
            controller: _searchCtrl,
            style: ts(13, FontWeight.w400, kText),
            decoration: InputDecoration(
              hintText: 'Search by patient name or ID…',
              hintStyle: ts(13, FontWeight.w400, kMuted2),
              prefixIcon: const Icon(Icons.search, size: 18, color: kMuted2),
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(7),
                borderSide: const BorderSide(color: kBorder2)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(7),
                borderSide: const BorderSide(color: kBorder2)),
            ),
          ),
        )),
        const SizedBox(width: 10),
        EhButton('Begin Assessment →', onTap: _goAssess),
      ]),
      const SizedBox(height: 14),

      if (_loading)
        const Center(child: Padding(padding: EdgeInsets.all(32),
          child: CircularProgressIndicator(color: kPrimary)))
      else if (_error != null)
        AlertBanner(_error!, isError: true)
      else
        _buildTable(),

      if (!_loading && _error == null) _buildPagination(),
    ]),
  );

  Widget _buildTable() {
    final rows = _paged;
    return Container(
      decoration: BoxDecoration(border: Border.all(color: kBorder), borderRadius: BorderRadius.circular(8)),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Table(
          columnWidths: const {
            0: FlexColumnWidth(2.5), 1: FlexColumnWidth(1), 2: FlexColumnWidth(1.2),
            3: FlexColumnWidth(1.5), 4: FlexColumnWidth(1.8), 5: FlexColumnWidth(2),
          },
          children: [
            TableRow(
              decoration: const BoxDecoration(color: kBg),
              children: ['Patient Name','Age','Gender','Status','Last Appointment','Last Diagnosis']
                  .map((h) => Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    child: Text(h, style: ts(11.5, FontWeight.w600, kMuted))))
                  .toList(),
            ),
            ...rows.map((p) {
              final pMap = p as Map<String, dynamic>;
              final isSelected = _selected != null &&
                  (_selected!['id'] ?? _selected!['patientId']) == (pMap['id'] ?? pMap['patientId']);
              final status = (pMap['Status'] ?? pMap['status'] ?? 'Active').toString();
              final isActive = status.toLowerCase() == 'active';
              return TableRow(
                decoration: BoxDecoration(
                  color: isSelected ? kPrimaryPale : kCard,
                  border: const Border(top: BorderSide(color: kBorder)),
                ),
                children: [
                  GestureDetector(
                    onTap: () => setState(() => _selected = pMap),
                    child: Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      child: Text(_name(pMap), style: ts(13, FontWeight.w600, kPrimary),
                        maxLines: 1, overflow: TextOverflow.ellipsis))),
                  _cell('${pMap['Age']??pMap['age']??'—'}'),
                  _cell('${pMap['Gender']??pMap['gender']??'—'}'),
                  TableRowInkWell(
                    onTap: () => setState(() => _selected = pMap),
                    child: Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: isActive ? kGreenPale : kRedPale,
                          borderRadius: BorderRadius.circular(999)),
                        child: Text(status, style: ts(11.5, FontWeight.w600, isActive ? kGreen : kRed))))),
                  _cell(_fmt(pMap['LastAppointment'] ?? pMap['lastAppointment'])),
                  _cell(() {
                    final s = (pMap['LastDiagnosis']??pMap['lastDiagnosis']??'—').toString();
                    return s.length > 30 ? '${s.substring(0,30)}…' : s;
                  }()),
                ],
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _cell(String text) => GestureDetector(
    onTap: () {},
    child: Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Text(text, style: ts(13, FontWeight.w400, kText2),
        maxLines: 1, overflow: TextOverflow.ellipsis)));

  Widget _buildPagination() {
    if (_totalPages <= 1) return const SizedBox(height: 8);
    return Padding(
      padding: const EdgeInsets.only(top: 14),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        _pageBtn(Icons.chevron_left, _page > 1 ? () => setState(() => _page--) : null),
        ...List.generate(_totalPages, (i) => _pageNumBtn(i + 1)),
        _pageBtn(Icons.chevron_right, _page < _totalPages ? () => setState(() => _page++) : null),
      ]),
    );
  }

  Widget _pageBtn(IconData icon, VoidCallback? onTap) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(6),
    child: Container(width: 30, height: 30, margin: const EdgeInsets.symmetric(horizontal: 2),
      decoration: BoxDecoration(border: Border.all(color: kBorder), borderRadius: BorderRadius.circular(6)),
      child: Icon(icon, size: 18, color: onTap != null ? kText2 : kMuted2)));

  Widget _pageNumBtn(int p) => InkWell(
    onTap: () => setState(() => _page = p),
    borderRadius: BorderRadius.circular(6),
    child: Container(width: 30, height: 30, margin: const EdgeInsets.symmetric(horizontal: 2),
      decoration: BoxDecoration(
        color: p == _page ? kPrimary : kCard,
        border: Border.all(color: p == _page ? kPrimary : kBorder),
        borderRadius: BorderRadius.circular(6)),
      child: Center(child: Text('$p',
        style: ts(12.5, FontWeight.w600, p == _page ? Colors.white : kText2)))));

  String _fmt(dynamic d) {
    if (d == null) return '—';
    try {
      final dt = DateTime.parse(d.toString());
      return '${dt.year}-${dt.month.toString().padLeft(2,'0')}-${dt.day.toString().padLeft(2,'0')}';
    } catch (_) { return d.toString(); }
  }
}
