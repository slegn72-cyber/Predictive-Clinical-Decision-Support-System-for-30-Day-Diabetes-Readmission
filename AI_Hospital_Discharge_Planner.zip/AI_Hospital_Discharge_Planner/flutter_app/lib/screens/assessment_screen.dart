import 'package:flutter/material.dart';
import '../theme.dart';
import '../widgets/shared.dart';
import '../services/api_service.dart';

class DischargeAssessmentScreen extends StatefulWidget {
  final Map<String, dynamic> patient;
  final Map<String, dynamic> details;
  final List<dynamic> visits, prescriptions, bloodtests;
  final String diagnosis, dischargeDate;

  const DischargeAssessmentScreen({
    super.key,
    required this.patient,
    required this.details,
    required this.visits,
    required this.prescriptions,
    required this.bloodtests,
    required this.diagnosis,
    required this.dischargeDate,
  });

  @override
  State<DischargeAssessmentScreen> createState() => _DischargeAssessmentScreenState();
}

class _DischargeAssessmentScreenState extends State<DischargeAssessmentScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  // AI results
  final _aiText    = <String, String>{'full':'','plan':'','meds':'','followup':''};
  final _aiLoading = <String, bool>{'full':false,'plan':false,'meds':false,'followup':false};
  Map<String, dynamic>? _lace, _labs, _social;

  // Checklist
  late List<_CheckItem> _checklist;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 5, vsync: this);
    _buildChecklist();
  }

  @override
  void dispose() { _tabs.dispose(); super.dispose(); }

  String get _patName {
    final p = widget.patient;
    final n = '${p['FName']??p['firstName']??''} ${p['LName']??p['lastName']??''}'.trim();
    return n.isEmpty ? 'Unknown' : n;
  }

  String get _age => '${widget.patient['Age']??widget.patient['age']??widget.details['age']??'?'}';
  String get _gender => '${widget.patient['Gender']??widget.patient['gender']??''}';

  Map<String, dynamic> _buildPayload() => {
    'name': _patName, 'age': _age, 'gender': _gender,
    'diagnosis': widget.diagnosis, 'dischargeDate': widget.dischargeDate,
    'details': widget.details,
    'visits': widget.visits,
    'prescriptions': widget.prescriptions,
    'bloodtests': widget.bloodtests,
  };

  Future<void> _runAgent(String section) async {
    setState(() => _aiLoading[section] = true);
    try {
      final r = await ApiService.assess(_buildPayload(), section);
      setState(() {
        _aiText[section] = r['text'] as String? ?? '';
        if (r['lace'] != null) _lace = r['lace'] as Map<String, dynamic>;
        if (r['labs'] != null) _labs = r['labs'] as Map<String, dynamic>;
        if (r['social'] != null) _social = r['social'] as Map<String, dynamic>;
      });
    } catch (e) {
      setState(() => _aiText[section] = 'Error: $e');
    } finally {
      setState(() => _aiLoading[section] = false);
    }
  }

  void _buildChecklist() {
    final diag = widget.diagnosis.toLowerCase();
    final rxCount = widget.prescriptions.length;
    final hasLabs = widget.bloodtests.isNotEmpty;
    final abnormalLabs = widget.bloodtests.where(_isAbnormal).toList();
    final hasAbnormalLabs = abnormalLabs.isNotEmpty;
    final rxNames = widget.prescriptions.take(5)
        .map((p) => (p['medicine_name'] ?? p['name'] ?? '').toString())
        .where((s) => s.isNotEmpty).join(', ');

    // Diagnosis-specific flags
    final isCardiac   = diag.contains('heart') || diag.contains('cardiac') || diag.contains('mi') || diag.contains('failure');
    final isDiabetes  = diag.contains('diabet');
    final isCopd      = diag.contains('copd') || diag.contains('lung') || diag.contains('pulmonary');
    final isStroke    = diag.contains('stroke') || diag.contains('cerebro');
    final isSepsis    = diag.contains('sepsis') || diag.contains('infection');
    final hasHighRxBurden = rxCount > 5;
    final hasPolypharmacy = rxCount > 7;

    _checklist = [
      // ── Clinical
      _CheckItem('Clinical', 'Discharge vitals stable and documented', checked: true),
      _CheckItem('Clinical', 'Primary diagnosis (${widget.diagnosis}) confirmed in discharge summary', checked: true),
      _CheckItem('Clinical', 'All active problems addressed or handed off'),
      if (isCardiac)
        _CheckItem('Clinical', 'Cardiac telemetry reviewed before discharge'),
      if (isDiabetes)
        _CheckItem('Clinical', 'Blood glucose stable and within target range before discharge'),
      if (isCopd)
        _CheckItem('Clinical', 'O₂ saturation ≥ 92% on room air confirmed'),
      if (isStroke)
        _CheckItem('Clinical', 'Swallowing assessment completed before oral medications'),
      if (isSepsis)
        _CheckItem('Clinical', 'Infection source identified and antibiotic course confirmed'),

      // ── Medications
      _CheckItem('Medications', 'Medication reconciliation completed (${rxCount} meds on record)', checked: rxCount > 0),
      if (rxCount > 0)
        _CheckItem('Medications', 'Patient counselled on: $rxNames'),
      if (hasHighRxBurden)
        _CheckItem('Medications', 'Pill organiser or blister pack arranged ($rxCount medications)'),
      if (hasPolypharmacy)
        _CheckItem('Medications', 'Pharmacist review completed — polypharmacy risk ($rxCount meds)'),
      if (isCardiac)
        _CheckItem('Medications', 'Anticoagulant / antiplatelet therapy reviewed and prescribed'),
      if (isDiabetes)
        _CheckItem('Medications', 'Insulin regimen or oral hypoglycaemics confirmed with patient'),
      _CheckItem('Medications', 'High-risk medications counselled (anticoag, insulin, opioids)'),
      _CheckItem('Medications', 'Medication list in readable format given to patient'),

      // ── Labs
      if (hasLabs)
        _CheckItem('Labs', '${widget.bloodtests.length} lab results reviewed', checked: !hasAbnormalLabs),
      if (hasAbnormalLabs)
        _CheckItem('Labs', '${abnormalLabs.length} abnormal result(s) — follow-up plan documented'),
      if (isCardiac)
        _CheckItem('Labs', 'BNP / troponin trend reviewed before discharge'),
      if (isDiabetes)
        _CheckItem('Labs', 'HbA1c reviewed and diabetes management plan updated'),
      _CheckItem('Labs', 'Post-discharge lab requisitions provided to patient'),

      // ── Education
      _CheckItem('Education', 'Patient educated on ${widget.diagnosis} self-management'),
      _CheckItem('Education', 'Red flag symptoms explained — when to return to ED'),
      if (isCardiac)
        _CheckItem('Education', 'Daily weight monitoring explained (≥2 kg gain = call doctor)'),
      if (isDiabetes)
        _CheckItem('Education', 'Blood glucose monitoring schedule given to patient'),
      if (isCopd)
        _CheckItem('Education', 'Inhaler technique demonstrated and confirmed'),
      _CheckItem('Education', 'Diet and activity restrictions discussed'),
      _CheckItem('Education', 'Teach-back completed — patient demonstrates understanding'),

      // ── Follow-up
      _CheckItem('Follow-up', 'Primary care follow-up booked (within ${isCardiac || isCopd ? "3" : "7"} days)'),
      if (isCardiac)
        _CheckItem('Follow-up', 'Cardiology follow-up booked within 2 weeks'),
      if (isDiabetes)
        _CheckItem('Follow-up', 'Endocrinology / diabetes educator referral placed'),
      if (isStroke)
        _CheckItem('Follow-up', 'Neurology and rehabilitation referral placed'),
      _CheckItem('Follow-up', 'Home care referral submitted if required'),

      // ── Social
      _CheckItem('Social', 'Social work consulted if social risk factors present'),
      _CheckItem('Social', 'Safe discharge destination confirmed', checked: true),
      _CheckItem('Social', 'Transport arranged'),

      // ── Documentation
      _CheckItem('Documentation', 'Discharge summary completed and signed'),
      _CheckItem('Documentation', 'Family physician notified (fax/letter sent)'),
      _CheckItem('Documentation', 'Patient given copy of discharge summary'),
    ];
  }

  bool _isAbnormal(dynamic bt) {
    final val  = double.tryParse('${bt['result_value'] ?? ''}');
    final norm = '${bt['normal_range'] ?? ''}';
    final m    = RegExp(r'([\d.]+)\s*[–\-]\s*([\d.]+)').firstMatch(norm);
    if (val == null || m == null) return false;
    return val < double.parse(m.group(1)!) || val > double.parse(m.group(2)!);
  }

  String _fmt(dynamic d) {
    if (d == null) return '—';
    try { final dt = DateTime.parse('$d'); return '${dt.year}-${dt.month.toString().padLeft(2,'0')}-${dt.day.toString().padLeft(2,'0')}'; }
    catch (_) { return '$d'; }
  }

  // ════════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: Column(children: [
        _topbar(),
        Expanded(child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _banner(),
            _statsRow(),
            _patientCard(),
            _agentCard(),
            if (_lace != null) _laceCard(),
            if (_labs != null && (_labs!['abnormal_count'] as int? ?? 0) > 0) _labsAICard(),
            if (_social != null) _socialCard(),
            if (widget.bloodtests.isNotEmpty) _rawLabsCard(),
            _tabsCard(),
          ]),
        )),
      ]),
    );
  }

  // ── Topbar ────────────────────────────────────────────────────────────────
  Widget _topbar() => Container(
    height: 56,
    padding: const EdgeInsets.symmetric(horizontal: 24),
    decoration: const BoxDecoration(color: kCard, border: Border(bottom: BorderSide(color: kBorder))),
    child: Row(children: [
      GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Row(children: [
          const Icon(Icons.chevron_left, color: kMuted, size: 18),
          Text('Doctor Portal', style: ts(13, FontWeight.w400, kMuted)),
        ]),
      ),
      Text(' / ', style: ts(13, FontWeight.w400, kBorder2)),
      Text('Discharge Planner', style: ts(13, FontWeight.w400, kMuted)),
      Text(' / ', style: ts(13, FontWeight.w400, kBorder2)),
      Text(_patName, style: ts(13, FontWeight.w500, kText2), maxLines: 1, overflow: TextOverflow.ellipsis),
      const Spacer(),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF7C3AED), Color(0xFF2563EB)]),
          borderRadius: BorderRadius.circular(999)),
        child: Text('✦ AI Assistant', style: ts(12, FontWeight.w600, Colors.white))),
      const SizedBox(width: 8),
      IconButton(icon: const Icon(Icons.notifications_none, color: kMuted, size: 20), onPressed: () {}),
      IconButton(icon: const Icon(Icons.person_outline, color: kMuted, size: 20), onPressed: () {}),
    ]),
  );

  // ── Banner ────────────────────────────────────────────────────────────────
  Widget _banner() => Container(
    width: double.infinity,
    margin: const EdgeInsets.only(bottom: 18),
    padding: const EdgeInsets.fromLTRB(22, 14, 22, 14),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFF1E40AF), Color(0xFF2563EB), Color(0xFF3B82F6)]),
      borderRadius: BorderRadius.circular(10)),
    child: Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('$_patName — Discharge Risk Assessment', style: ts(16, FontWeight.w800, Colors.white)),
        const SizedBox(height: 2),
        Text('${widget.diagnosis}  ·  Discharge: ${widget.dischargeDate}',
          style: ts(12.5, FontWeight.w400, Colors.white.withOpacity(.85))),
      ])),
      TextButton(
        onPressed: () => Navigator.pop(context),
        style: TextButton.styleFrom(
          backgroundColor: Colors.white.withOpacity(.15),
          foregroundColor: Colors.white,
          side: BorderSide(color: Colors.white.withOpacity(.3)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(7)),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        ),
        child: Text('← Back to Patients', style: ts(13, FontWeight.w600, Colors.white)),
      ),
    ]),
  );

  // ── Stats row ─────────────────────────────────────────────────────────────
  Widget _statsRow() {
    final laceTotal = _lace?['total'];
    final laceLevel = _lace?['level'] as String?;
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(children: [
        _statCard('Visits on Record', '${widget.visits.length}', 'Total visits'),
        const SizedBox(width: 12),
        _statCard('Medications', '${widget.prescriptions.length}', 'Prescriptions'),
        const SizedBox(width: 12),
        _statCard('Lab Results', '${widget.bloodtests.length}', 'Blood tests'),
        const SizedBox(width: 12),
        _statCard('LACE Risk', laceTotal != null ? '$laceTotal/19' : '—', 'Run assessment',
          valueColor: laceTotal != null ? levelColor(laceLevel) : kMuted),
      ]),
    );
  }

  Widget _statCard(String label, String value, String sub, {Color? valueColor}) => Expanded(
    child: Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(10),
        border: Border.all(color: kBorder),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.04), blurRadius: 4, offset: const Offset(0,2))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: ts(11, FontWeight.w600, kMuted)),
        const SizedBox(height: 4),
        Text(value, style: ts(22, FontWeight.w800, valueColor ?? kText)),
        const SizedBox(height: 2),
        Text(sub, style: ts(11, FontWeight.w400, kMuted)),
      ]),
    ),
  );

  // ── Patient info card ─────────────────────────────────────────────────────
  Widget _infoCell(String label, String value) => SizedBox(width: 200,
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: ts(10.5, FontWeight.w600, kMuted)),
      const SizedBox(height: 2),
      Text(value, style: ts(13, FontWeight.w500, kText2), maxLines: 1, overflow: TextOverflow.ellipsis),
    ]));

  Widget _patientCard() {
    final d = widget.details;
    final p = widget.patient;
    final gender  = _gender.isEmpty ? '—' : _gender;
    final address = (d['Address'] ?? d['address'] ?? '—').toString();
    final phone   = (d['tel'] ?? d['phone'] ?? p['MobileNumber'] ?? '—').toString();
    final email   = (d['EmailId'] ?? d['email'] ?? '—').toString();
    final height  = (d['height'] ?? '—').toString();
    final weight  = (d['weight'] ?? '—').toString();
    final lastDx  = (p['LastDiagnosis'] ?? p['lastDiagnosis'] ?? '—').toString();

    return EhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      CardTitle(_patName),
      const SizedBox(height: 14),
      Wrap(spacing: 16, runSpacing: 12, children: [
        _infoCell('Age / Gender',    '$_age yr / $gender'),
        _infoCell('Address',         address),
        _infoCell('Phone',           phone),
        _infoCell('Email',           email),
        _infoCell('Height / Weight', '$height / $weight'),
        _infoCell('Last Diagnosis',  lastDx),
      ]),
    ]));
  }

  // ── Agent card ────────────────────────────────────────────────────────────
  Widget _agentCard() {
    final running = _aiLoading['full'] ?? false;
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF1E1B4B), Color(0xFF1E40AF)]),
        borderRadius: BorderRadius.circular(10)),
      padding: const EdgeInsets.all(20),
      child: Row(children: [
        Container(width: 46, height: 46,
          decoration: BoxDecoration(color: Colors.white.withOpacity(.15), borderRadius: BorderRadius.circular(12)),
          child: const Center(child: Text('🤖', style: TextStyle(fontSize: 24)))),
        const SizedBox(width: 16),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('AI Discharge Risk Agent', style: ts(15, FontWeight.w700, Colors.white)),
          Text('GPT-4o with tool-calling — LACE Index · Lab Interpretation · Social Risk',
            style: ts(12, FontWeight.w400, Colors.white.withOpacity(.8))),
          const SizedBox(height: 8),
          Text('① Computes LACE Index  ·  ② Interprets lab results  ·  ③ Assesses social risk  ·  ④ Generates clinical report',
            style: ts(11.5, FontWeight.w400, Colors.white.withOpacity(.75))),
        ])),
        const SizedBox(width: 16),
        ElevatedButton(
          onPressed: running ? null : () => _runAgent('full'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.white, foregroundColor: kPrimary,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            textStyle: ts(14, FontWeight.w700, kPrimary),
          ),
          child: running
            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: kPrimary))
            : const Text('🚀 Run Assessment'),
        ),
      ]),
    );
  }

  // ── LACE card ─────────────────────────────────────────────────────────────
  Widget _laceCard() {
    final lace  = _lace!;
    final total = lace['total'] as int? ?? 0;
    final level = lace['level'] as String? ?? 'LOW';
    final c     = levelColor(level);
    final bg    = levelBg(level);
    final barColors = [const Color(0xFF6366F1), kRed, kYellow, const Color(0xFF0891B2)];
    final comps = [
      {'l':'L','label':'Length of Stay',         'score':lace['l']??0,'max':4,'note':lace['l_reason']??''},
      {'l':'A','label':'Acuity of Admission',     'score':lace['a']??0,'max':3,'note':lace['a_reason']??''},
      {'l':'C','label':'Comorbidities (Charlson)','score':lace['c']??0,'max':5,'note':lace['c_reason']??''},
      {'l':'E','label':'ED Visits (last 6 mo)',   'score':lace['e']??0,'max':4,'note':lace['e_reason']??''},
    ];
    return EhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const CardTitle('LACE Index Score', subtitle: 'Validated 30-day readmission model  •  Score ≥ 10 = High Risk'),
        const Spacer(),
        RiskPill(level),
      ]),
      const SizedBox(height: 16),
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Gauge
        Column(children: [
          Container(
            width: 110, height: 110,
            decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: c, width: 9), color: bg),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text('$total', style: ts(30, FontWeight.w800, c)),
              Text('/ 19', style: ts(11, FontWeight.w400, kMuted)),
            ]),
          ),
          const SizedBox(height: 10),
          RiskPill(level, large: true),
          const SizedBox(height: 8),
          SizedBox(width: 140, child: Text(lace['interpretation'] ?? '',
            textAlign: TextAlign.center, style: ts(11, FontWeight.w400, kMuted).copyWith(height: 1.5))),
        ]),
        const SizedBox(width: 20),
        // Bars
        Expanded(child: Column(children: [
          ...comps.asMap().entries.map((e) => LaceBar(
            letter: e.value['l'] as String,
            label:  e.value['label'] as String,
            note:   e.value['note'] as String,
            score: (e.value['score'] as int?) ?? 0,
            max:   (e.value['max']   as int?) ?? 4,
            color: barColors[e.key],
          )),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(color: kBg, borderRadius: BorderRadius.circular(8)),
            child: Row(children: [
              Text('Total LACE Score', style: ts(13, FontWeight.w700, kText)),
              const Spacer(),
              Text('$total / 19', style: ts(17, FontWeight.w800, c)),
            ]),
          ),
        ])),
      ]),
      const SizedBox(height: 10),
      Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(8)),
        child: Text(lace['interpretation'] ?? '', style: ts(12, FontWeight.w400, c).copyWith(height: 1.5))),
    ]));
  }

  // ── AI Labs card ──────────────────────────────────────────────────────────
  Widget _labsAICard() {
    final labs    = _labs!;
    final abnList = labs['abnormal'] as List? ?? [];
    return EhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const CardTitle('Lab Interpretation'),
        const SizedBox(width: 8),
        InfoChip('${labs['abnormal_count']} Abnormal', bg: kRedPale, fg: kRed),
      ]),
      const SizedBox(height: 4),
      Text('${labs['summary'] ?? ''}', style: ts(12, FontWeight.w400, kMuted)),
      const SizedBox(height: 12),
      ...abnList.map((a) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: kRedBg, borderRadius: BorderRadius.circular(8),
          border: Border.all(color: kRed.withOpacity(.15))),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(color: kRed, borderRadius: BorderRadius.circular(5)),
            child: Text('${a['direction']}', style: ts(10.5, FontWeight.w700, Colors.white))),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text('${a['name']}', style: ts(13, FontWeight.w700, kText)),
              const SizedBox(width: 6),
              Text('${a['value']} ${a['unit']}', style: ts(13, FontWeight.w600, kRed)),
              const SizedBox(width: 4),
              Text('(normal: ${a['range']})', style: ts(11, FontWeight.w400, kMuted)),
            ]),
            const SizedBox(height: 3),
            Text('${a['significance']}', style: ts(12, FontWeight.w400, kText2).copyWith(height: 1.4)),
          ])),
        ]),
      )),
    ]));
  }

  // ── Social card ───────────────────────────────────────────────────────────
  Widget _socialCard() {
    final social  = _social!;
    final level   = social['social_risk_level'] as String? ?? 'LOW';
    final factors = social['factors'] as List? ?? [];
    final c = levelColor(level);
    final bgMap = {'HIGH':kRedBg,'MODERATE':kYellowBg,'LOW':kGreenBg};
    final brdMap = {'HIGH':kRed.withOpacity(.15),'MODERATE':kYellow.withOpacity(.15),'LOW':kGreen.withOpacity(.15)};
    return EhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const CardTitle('Social Risk Assessment'),
        const Spacer(),
        RiskPill(level),
      ]),
      const SizedBox(height: 12),
      ...factors.map((f) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: bgMap[f['risk']] ?? kBg,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: brdMap[f['risk']] ?? kBorder)),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(color: levelColor(f['risk'] as String?), borderRadius: BorderRadius.circular(5)),
            child: Text('${f['risk']}', style: ts(10.5, FontWeight.w700, Colors.white))),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${f['factor']}', style: ts(12.5, FontWeight.w600, kText)),
            const SizedBox(height: 2),
            Text('${f['note']}', style: ts(12, FontWeight.w400, kText2)),
          ])),
        ]),
      )),
      const SizedBox(height: 4),
      Text('${social['recommendation'] ?? ''}', style: ts(12.5, FontWeight.w600, c)),
    ]));
  }

  // ── Raw labs card ─────────────────────────────────────────────────────────
  Widget _rawLabsCard() => EhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const CardTitle('Lab Results from Database'),
    const SizedBox(height: 12),
    Wrap(spacing: 10, runSpacing: 10, children: widget.bloodtests.take(8).map((bt) {
      final abn = _isAbnormal(bt);
      return Container(
        width: 140, padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: abn ? kRedBg : kBg, borderRadius: BorderRadius.circular(8),
          border: abn ? Border.all(color: kRed.withOpacity(.25)) : null),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${bt['result_value']??'—'} ${bt['unit']??''}',
            style: ts(18, FontWeight.w800, abn ? kRed : kPrimaryL)),
          const SizedBox(height: 3),
          Text('${bt['test_name']??'Test'}', style: ts(11.5, FontWeight.w600, kText)),
          if ('${bt['normal_range']??''}'.isNotEmpty)
            Text('Normal: ${bt['normal_range']}', style: ts(10, FontWeight.w400, kMuted)),
          if (abn) Text('⚠ Abnormal', style: ts(10, FontWeight.w700, kRed)),
        ]),
      );
    }).toList()),
  ]));

  // ── Tabs card ─────────────────────────────────────────────────────────────
  Widget _tabsCard() => EhCard(
    padding: const EdgeInsets.all(0),
    child: Column(children: [
      TabBar(
        controller: _tabs, isScrollable: true,
        labelColor: kPrimaryL, unselectedLabelColor: kMuted,
        labelStyle: ts(13, FontWeight.w600, kPrimaryL),
        unselectedLabelStyle: ts(13, FontWeight.w500, kMuted),
        indicatorColor: kPrimaryL, indicatorWeight: 2,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        tabs: const [
          Tab(text: '📊 Full Assessment'),
          Tab(text: '📋 Discharge Plan'),
          Tab(text: '💊 Medications'),
          Tab(text: '📅 Follow-up'),
          Tab(text: '✅ Checklist'),
        ],
      ),
      const Divider(height: 1),
      Padding(
        padding: const EdgeInsets.all(20),
        child: SizedBox(
          height: 560,
          child: TabBarView(controller: _tabs, children: [
            _aiTab('full',     '🚀 Run Full Assessment',        () => _runAgent('full')),
            _aiTab('plan',     '⚡ Generate Discharge Plan',    () => _runAgent('plan')),
            _aiTab('meds',     '⚡ Generate Medication Review', () => _runAgent('meds')),
            _aiTab('followup', '⚡ Generate Follow-up Schedule',() => _runAgent('followup')),
            _checklistTab(),
          ]),
        ),
      ),
    ]),
  );

  Widget _aiTab(String key, String label, VoidCallback onTap) {
    final loading = _aiLoading[key] ?? false;
    final text    = _aiText[key]    ?? '';
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      EhButton(loading ? 'Agent working…' : label, onTap: loading ? null : onTap, loading: loading),
      const SizedBox(height: 14),
      Expanded(child: text.isEmpty
        ? EmptyState(icon: '🤖', text: 'Click above to generate using real patient data')
        : SingleChildScrollView(child: AiOutputBox(text))),
    ]);
  }

  Widget _checklistTab() {
    final done  = _checklist.where((i) => i.checked).length;
    final total = _checklist.length;
    final pct   = (done / total * 100).round();
    final cats  = _checklist.map((i) => i.category).toSet().toList();
    return StatefulBuilder(builder: (ctx, setSt) {
      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text('$done/$total completed', style: ts(13, FontWeight.w600, kText)),
          const SizedBox(width: 12),
          Expanded(child: ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(value: done/total, backgroundColor: kBorder, color: kPrimaryL, minHeight: 7))),
          const SizedBox(width: 12),
          InfoChip('$pct%'),
        ]),
        const SizedBox(height: 12),
        Expanded(child: SingleChildScrollView(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: cats.map((cat) => Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SectionLabel(cat),
              ..._checklist.where((i) => i.category == cat).map((item) =>
                GestureDetector(
                  onTap: () => setSt(() => item.checked = !item.checked),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 6),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                    decoration: BoxDecoration(color: kBg, borderRadius: BorderRadius.circular(7)),
                    child: Row(children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 150),
                        width: 17, height: 17,
                        decoration: BoxDecoration(
                          color: item.checked ? kPrimary : Colors.transparent,
                          border: Border.all(color: item.checked ? kPrimary : kBorder2, width: 1.5),
                          borderRadius: BorderRadius.circular(4)),
                        child: item.checked
                          ? const Icon(Icons.check, size: 11, color: Colors.white) : null),
                      const SizedBox(width: 9),
                      Expanded(child: Text(item.label, style: ts(12.5, FontWeight.w400,
                        item.checked ? kMuted : kText2).copyWith(
                          decoration: item.checked ? TextDecoration.lineThrough : null))),
                      InfoChip(cat),
                    ]),
                  ),
                ),
              ),
            ],
          )).toList(),
        ))),
      ]);
    });
  }
}

class _CheckItem {
  final String category, label;
  bool checked;
  _CheckItem(this.category, this.label, {this.checked = false});
}
