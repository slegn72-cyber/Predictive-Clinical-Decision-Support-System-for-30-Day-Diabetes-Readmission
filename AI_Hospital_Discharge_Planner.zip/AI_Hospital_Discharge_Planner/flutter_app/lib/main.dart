import 'package:flutter/material.dart';
import 'theme.dart';
import 'screens/patient_list_screen.dart';

void main() => runApp(const DischargeApp());

class DischargeApp extends StatelessWidget {
  const DischargeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'eHospital – Discharge Risk Assessment',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: kFontFamily,
        colorScheme: ColorScheme.fromSeed(seedColor: kPrimary),
        useMaterial3: false,
        scaffoldBackgroundColor: kBg,
      ),
      home: Scaffold(
        backgroundColor: kBg,
        body: DischargePatientListScreen(
          doctor: const {'id': 58, 'name': 'Test Doctor'},
        ),
      ),
    );
  }
}
