# Discharge Planner — Integration Instructions for Ahmad

## Files to copy into the main project

Copy these into `lib/View/Screens/discharge/` (create that folder):

- `lib/screens/patient_list_screen.dart`   → rename: `Discharge_Patient_List_Screen.dart`
- `lib/screens/assessment_screen.dart`     → rename: `Discharge_Assessment_Screen.dart`
- `lib/widgets/shared.dart`                → copy to `lib/View/Screens/discharge/`
- `lib/services/api_service.dart`          → copy to `lib/View/Screens/discharge/`
- `lib/theme.dart`                         → copy to `lib/View/Screens/discharge/`

## Add to Doctor Dashboard sidebar
In `Doctor_Dashboard_Screen.dart`:

```dart
// In _buildSidebar():
_menuItem(Icons.assignment_turned_in_outlined, 'Discharge Planner', 8, isDrawer),

// In _buildContent():
} else if (selectedIndex == 8) {
  return DischargePatientListScreen(doctor: widget.doctor);
}

// Import:
import 'package:ehosptal_flutter_revamp/View/Screens/discharge/Discharge_Patient_List_Screen.dart';
```

## Backend
Make sure `backend/app.py` is running at `http://localhost:8000`.
Set your OpenAI key in `backend/app.py` before running.
