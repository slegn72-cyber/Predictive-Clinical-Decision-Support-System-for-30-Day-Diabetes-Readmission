# eHospital — Discharge Risk Assessment Module

## Structure
```
ehospital_discharge_module/
├── backend/          ← Python Flask + OpenAI Agent
│   ├── app.py        ← Paste your OpenAI key here (line 11)
│   └── requirements.txt
└── flutter_app/      ← Flutter standalone demo app
    ├── lib/
    └── pubspec.yaml
```

## Step 1 — Start the backend
```bash
cd backend
pip3 install -r requirements.txt
# Open app.py and paste your OpenAI key on line 11
python3 app.py
```
Backend runs at: http://localhost:8000

## Step 2 — Run the Flutter app
```bash
cd flutter_app
flutter pub get
flutter run
```

## Demo flow
1. Log in with eHospital doctor credentials
2. Browse patient table — search, paginate, select a row
3. Set diagnosis + discharge date → click Begin Assessment
4. Click 🚀 Run Assessment — AI agent runs automatically
5. See: LACE score, lab interpretation, social risk + 5 tabs
