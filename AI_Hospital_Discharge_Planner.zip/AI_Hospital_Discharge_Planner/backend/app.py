"""
eHospital – Discharge Risk Assessment Module
Run:  python3 app.py
Open: http://localhost:8000
"""
import json, re
from datetime import datetime, timedelta
from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
import requests
from openai import OpenAI

OPENAI_API_KEY = "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"   # ← paste here
EHOSPITAL_BASE = "https://tysnx3mi2s.us-east-1.awsapprunner.com"

app    = Flask(__name__)
CORS(app)
client = OpenAI(api_key=OPENAI_API_KEY)

# ── eHospital proxy ───────────────────────────────────────────────────────────
def eh(path, body):
    try:
        r = requests.post(f"{EHOSPITAL_BASE}{path}", json=body,
                          headers={"Content-Type":"application/json"}, timeout=15)
        if r.ok: return r.json()
    except Exception as e: print(f"[eH] {path}: {e}")
    return {}

# ── LACE Tool ─────────────────────────────────────────────────────────────────
def tool_lace(visits, diag_notes):
    l = 1
    if len(visits) >= 2:
        try:
            dates = sorted([datetime.fromisoformat(v["date"].replace("Z","")) for v in visits if v.get("date")])
            if len(dates) >= 2:
                d = (dates[-1]-dates[0]).days
                l = 4 if d>=14 else 3 if d>=7 else 2 if d>=3 else 1
        except: pass
    emergency = bool(re.search(r"emerg|urgent|acute|911|ambulance|icu|intensive", diag_notes, re.I))
    a = 3 if emergency else 0
    cmap = [(r"mi|myocardial|heart attack",1),(r"heart failure|chf",1),(r"peripheral vascular|pvd",1),
            (r"stroke|cerebrovascular|tia",1),(r"dementia|alzheimer",1),(r"copd|emphysema|chronic lung",1),
            (r"diabet",1),(r"renal|kidney|ckd",2),(r"cancer|malignancy|tumor|carcinoma",2),(r"liver disease|cirrhosis",1)]
    c = min(sum(p for pat,p in cmap if re.search(pat,diag_notes,re.I)), 5)
    cutoff = datetime.now()-timedelta(days=180)
    ed = 0
    for v in visits:
        try:
            d2 = datetime.fromisoformat(v["date"].replace("Z",""))
            t  = f"{v.get('reason_for_visit','')} {v.get('observations','')}".lower()
            if d2>cutoff and re.search(r"emerg|ed visit|\ber\b|urgent care",t): ed+=1
        except: pass
    e = min(ed,4)
    total = l+a+c+e
    level = "HIGH" if total>=10 else "MODERATE" if total>=5 else "LOW"
    return {"l":l,"a":a,"c":c,"e":e,"total":total,"max":19,"level":level,
            "l_reason":f"{l} pt(s) — estimated from visit history",
            "a_reason":"Emergency admission detected (3 pts)" if emergency else "Non-emergency admission (0 pts)",
            "c_reason":f"{c} pt(s) — Charlson comorbidity score from diagnosis notes",
            "e_reason":f"{ed} ED visit(s) in last 6 months → {e} pt(s)",
            "interpretation":("LACE ≥ 10 — HIGH 30-day readmission risk. Intensive discharge support strongly recommended." if total>=10 else
                              "LACE 5–9 — MODERATE risk. Structured follow-up within 1 week recommended." if total>=5 else
                              "LACE < 5 — LOW risk. Standard discharge planning applies.")}

# ── Labs Tool ─────────────────────────────────────────────────────────────────
def _sig(name, direction):
    n = name.lower()
    if "hemoglobin" in n or "hgb" in n: return "Anaemia – reduced O₂ capacity; consider transfusion threshold."
    if "wbc" in n or "white" in n: return "Leukocytosis – possible infection/inflammation." if direction=="HIGH" else "Leukopenia – infection risk."
    if "platelet" in n: return "Thrombocytopenia – bleeding risk; hold anticoagulants if <50." if direction=="LOW" else "Thrombocytosis – clotting risk."
    if "creatinine" in n: return "Renal impairment – adjust renally-cleared medications before discharge."
    if "sodium" in n: return "Hyponatremia – seizure risk; correct cautiously." if direction=="LOW" else "Hypernatremia – dehydration; IV fluid management."
    if "potassium" in n: return "Hypokalaemia – arrhythmia risk; replace electrolytes." if direction=="LOW" else "Hyperkalaemia – cardiac risk; hold K-sparing agents."
    if "glucose" in n: return "Hypoglycaemia – immediate correction required." if direction=="LOW" else "Hyperglycaemia – optimise diabetes management."
    if "bnp" in n: return "Elevated BNP – heart failure marker; optimise diuresis before discharge."
    if "troponin" in n: return "Elevated troponin – cardiac injury marker; cardiology review required."
    return f"Abnormal {direction.lower()} – clinical review recommended."

def tool_labs(bloodtests):
    abn, norm = [], []
    for bt in bloodtests:
        name,val,unit,nr = bt.get("test_name",""),bt.get("result_value",""),bt.get("unit",""),bt.get("normal_range","")
        try: num = float(str(val).replace(",",""))
        except: norm.append({"name":name,"value":val,"unit":unit,"range":nr}); continue
        m = re.search(r"([\d.]+)\s*[–\-]\s*([\d.]+)", nr)
        if not m: norm.append({"name":name,"value":val,"unit":unit,"range":nr}); continue
        lo,hi = float(m.group(1)),float(m.group(2))
        if num<lo or num>hi:
            d2 = "LOW" if num<lo else "HIGH"
            abn.append({"name":name,"value":val,"unit":unit,"range":nr,"direction":d2,"significance":_sig(name,d2)})
        else: norm.append({"name":name,"value":val,"unit":unit,"range":nr})
    return {"abnormal_count":len(abn),"normal_count":len(norm),"abnormal":abn,"normal":norm,
            "summary":f"{len(abn)} abnormal result(s) requiring clinical review." if abn else "All results within normal range."}

# ── Social Tool ───────────────────────────────────────────────────────────────
def tool_social(details, visits, prescriptions):
    factors,score = [],0
    addr = str(details.get("Address") or details.get("address") or "").strip()
    if not addr or addr in ("—","n/a",""):
        factors.append({"factor":"Housing","risk":"HIGH","note":"No address on record – possible housing instability."}); score+=3
    else: factors.append({"factor":"Housing","risk":"LOW","note":"Address documented."})
    phone = str(details.get("tel") or details.get("phone") or "").strip()
    if not phone or phone in ("—",""):
        factors.append({"factor":"Communication","risk":"MODERATE","note":"No phone number – difficulty reaching patient post-discharge."}); score+=2
    rx = len(prescriptions)
    if rx>7: factors.append({"factor":"Polypharmacy","risk":"HIGH","note":f"{rx} medications – high adherence burden and interaction risk."}); score+=3
    elif rx>3: factors.append({"factor":"Polypharmacy","risk":"MODERATE","note":f"{rx} medications – adherence counselling recommended."}); score+=1
    if len(visits)>5: factors.append({"factor":"Healthcare Utilisation","risk":"HIGH","note":f"{len(visits)} visits – may indicate unmet social needs."}); score+=2
    level = "HIGH" if score>=6 else "MODERATE" if score>=3 else "LOW"
    return {"social_risk_level":level,"social_risk_score":score,"factors":factors,
            "recommendation":("Social work referral strongly recommended before discharge." if level=="HIGH" else
                              "Community support assessment recommended." if level=="MODERATE" else
                              "Standard social screening adequate.")}

# ── Agent ─────────────────────────────────────────────────────────────────────
TOOLS = [
    {"type":"function","function":{"name":"compute_lace_score","description":"Compute LACE Index (0-19) for 30-day readmission risk.","parameters":{"type":"object","properties":{"visits":{"type":"array","items":{"type":"object"}},"diag_notes":{"type":"string"}},"required":["visits","diag_notes"]}}},
    {"type":"function","function":{"name":"interpret_labs","description":"Interpret blood tests, flag abnormals with clinical significance.","parameters":{"type":"object","properties":{"bloodtests":{"type":"array","items":{"type":"object"}}},"required":["bloodtests"]}}},
    {"type":"function","function":{"name":"assess_social_risk","description":"Evaluate social determinants of health risk.","parameters":{"type":"object","properties":{"details":{"type":"object"},"visits":{"type":"array","items":{"type":"object"}},"prescriptions":{"type":"array","items":{"type":"object"}}},"required":["details","visits","prescriptions"]}}},
]
TOOL_MAP = {
    "compute_lace_score": lambda a: tool_lace(a["visits"], a["diag_notes"]),
    "interpret_labs":     lambda a: tool_labs(a["bloodtests"]),
    "assess_social_risk": lambda a: tool_social(a["details"], a["visits"], a["prescriptions"]),
}
SYS_BASE = "You are a clinical AI agent at eHospital. Always call tools before responding. Be specific, evidence-based, and personalised to the patient. Reference clinical guidelines (ACC/AHA, GOLD, ADA, CMS) where applicable."

SYS_FULL = SYS_BASE + """
Call ALL THREE tools first (compute_lace_score, interpret_labs, assess_social_risk), then produce:
## 📊 Risk Summary
LACE score breakdown, overall risk level, and what it means for this patient.
## 🔬 Lab Findings
Abnormal results with clinical significance. If all normal, state that clearly.
## 🏠 Social Risk Factors
Housing, communication, polypharmacy, healthcare utilisation risks.
## ⚡ Top 3 Clinical Priorities Before Discharge
The most urgent actions before this patient leaves.
## 📋 Discharge Plan
Home care instructions, activity restrictions, diet, self-monitoring, when to call 911.
## 💊 Medication Recommendations
Key medications for this diagnosis, adjustments based on labs.
## 📅 Follow-up Schedule
Specific dates/timeframes based on LACE risk level.
## ⚠️ Red Flag Symptoms
Specific symptoms this patient should watch for based on their diagnosis.
## 🏥 Disposition
Recommended discharge destination and support level."""

SYS_PLAN = SYS_BASE + """
Call ALL THREE tools first, then produce ONLY a detailed discharge plan. Do NOT include risk scores or lab sections.
## 🏠 Discharge Plan for [Patient Name]
### Home Care Instructions
Step-by-step instructions for this specific diagnosis.
### Activity & Rest
What they can and cannot do in the first 2 weeks.
### Diet & Nutrition
Specific dietary guidance for this diagnosis.
### Self-Monitoring
What to check at home (weight, BP, glucose, etc.) and how often.
### When to Return to ED Immediately
Specific red flag symptoms for THIS diagnosis.
### Emergency Contacts
Who to call and when."""

SYS_MEDS = SYS_BASE + """
Call interpret_labs first, then compute_lace_score, then produce ONLY a medication review. Do NOT include risk scores or discharge plan sections.
## 💊 Medication Review for [Patient Name]
### Current Medications Analysis
Review each medication on record — purpose, dose considerations, interactions.
### Recommended Medication Changes
Based on diagnosis and lab results, what should be added, adjusted, or stopped.
### High-Risk Medications
Flag any anticoagulants, insulin, opioids, digoxin, or narrow-therapeutic-index drugs.
### Medication Counselling Points
What to tell the patient about their top 3-5 medications.
### Adherence Plan
Simple schedule and tips for this patient's medication burden."""

SYS_FOLLOWUP = SYS_BASE + """
Call compute_lace_score first to determine risk level, then produce ONLY a follow-up schedule. Do NOT include medication or discharge plan sections.
## 📅 Follow-up Schedule for [Patient Name]
### Discharge Day
Immediate actions before leaving hospital.
### Week 1 (Days 1-7)
Specific appointments, labs, and check-ins.
### Week 2-4
What should happen in the first month.
### Month 2-3
Ongoing monitoring plan.
### Month 4-6
Long-term follow-up milestones.
### Key Specialists
Which specialists to see and why, based on this patient's diagnosis and comorbidities."""

def run_agent(patient_data, section):
    visits  = patient_data.get("visits",[])
    presc   = patient_data.get("prescriptions",[])
    labs    = patient_data.get("bloodtests",[])
    details = patient_data.get("details",{})
    name    = patient_data.get("name","Unknown")
    age     = patient_data.get("age","?")
    gender  = patient_data.get("gender","")
    diag    = patient_data.get("diagnosis","Unknown")
    ddate   = patient_data.get("dischargeDate","")
    diag_notes = " ".join([f"{v.get('reason_for_visit','')} {v.get('observations','')} {v.get('diagnosis','')}" for v in visits]+[diag])
    med_names = ", ".join([p.get("medicine_name","") for p in presc[:10] if p.get("medicine_name")]) or "none on record"
    abnormal_labs = [bt.get("test_name","") for bt in labs if bt.get("result_value") and bt.get("normal_range")]

    prompts = {
        "full":     f"Run full discharge risk assessment for {name}, {age}yo {gender}. Diagnosis: {diag}. Discharge date: {ddate}. They have {len(visits)} hospital visits, {len(presc)} medications ({med_names}), and {len(labs)} lab results. Call ALL THREE tools then write the complete assessment.",
        "plan":     f"Write a personalised discharge plan for {name}, {age}yo {gender} being discharged with {diag} on {ddate}. They have {len(presc)} medications and {len(visits)} prior visits. Call ALL THREE tools first so you have their full risk profile, then write the plan.",
        "meds":     f"Do a full medication review for {name}, {age}yo {gender} with {diag}. Current medications: {med_names}. They have {len(labs)} lab results. Call interpret_labs first to check for any values affecting medication safety, then compute_lace_score for risk context, then write the complete medication review.",
        "followup": f"Create a detailed follow-up schedule for {name}, {age}yo {gender} with {diag}, discharging on {ddate}. Call compute_lace_score first — the LACE risk level determines follow-up intensity. Then call the other tools for full context. Write a week-by-week schedule through 6 months.",
    }
    sys_map = {"full": SYS_FULL, "plan": SYS_PLAN, "meds": SYS_MEDS, "followup": SYS_FOLLOWUP}
    messages = [{"role":"system","content":sys_map.get(section, SYS_FULL)},{"role":"user","content":prompts.get(section,prompts["full"])}]
    tool_results = {}
    for _ in range(8):
        resp = client.chat.completions.create(model="gpt-4o",messages=messages,tools=TOOLS,tool_choice="auto",temperature=0.2,max_tokens=2000)
        msg = resp.choices[0].message
        if not msg.tool_calls:
            return {"text":msg.content or "","lace":tool_results.get("compute_lace_score"),
                    "labs":tool_results.get("interpret_labs"),"social":tool_results.get("assess_social_risk")}
        messages.append({"role":"assistant","content":msg.content,
                         "tool_calls":[{"id":tc.id,"type":"function","function":{"name":tc.function.name,"arguments":tc.function.arguments}} for tc in msg.tool_calls]})
        for tc in msg.tool_calls:
            fn = tc.function.name
            try:
                args = json.loads(tc.function.arguments)
                if fn=="compute_lace_score": args["visits"]=visits; args["diag_notes"]=diag_notes
                elif fn=="interpret_labs": args["bloodtests"]=labs
                elif fn=="assess_social_risk": args["details"]=details; args["visits"]=visits; args["prescriptions"]=presc
                result = TOOL_MAP[fn](args); tool_results[fn]=result
            except Exception as ex: result={"error":str(ex)}
            messages.append({"role":"tool","tool_call_id":tc.id,"content":json.dumps(result)})
    return {"text":"Agent could not complete.","lace":tool_results.get("compute_lace_score"),
            "labs":tool_results.get("interpret_labs"),"social":tool_results.get("assess_social_risk")}

# ── Routes ────────────────────────────────────────────────────────────────────
@app.route("/")
def index(): return render_template("index.html")

@app.route("/health")
def health(): return jsonify({"status":"ok","service":"eHospital Discharge Risk Agent"})

@app.route("/api/login", methods=["POST"])
def login():
    d = request.json or {}
    r = eh("/api/users/login",{"email":d.get("email"),"password":d.get("password"),"selectedOption":"Doctor"})
    if not r or ("id" not in r and "doctor_id" not in r): return jsonify({"error":"Login failed. Check your credentials."}),401
    return jsonify(r)

@app.route("/api/patients", methods=["POST"])
def get_patients():
    d = request.json or {}
    did = d.get("doctorId")
    r = eh("/DoctorPatientsAuthorized",{"doctorId":did,"doctor_id":did})
    return jsonify(r if isinstance(r,list) else r.get("result",r.get("data",[])))

@app.route("/api/patient-data", methods=["POST"])
def get_patient_data():
    d = request.json or {}
    pid,did = d.get("patientId"),d.get("doctorId",58)
    det   = eh("/api/users/getPatientPortalInfoById",{"patientId":pid})
    vis   = eh("/patientVisits",{"patientId":str(pid),"doctorId":did})
    presc = eh("/getPrescriptionsByPatientId",{"patientId":pid})
    labs  = eh("/getBloodtestByPatientId",{"patientId":pid})
    return jsonify({"details":det if isinstance(det,dict) else {},
                    "visits":vis if isinstance(vis,list) else [],
                    "prescriptions":presc if isinstance(presc,list) else [],
                    "bloodtests":labs if isinstance(labs,list) else []})

@app.route("/api/assess", methods=["POST"])
def assess():
    d = request.json or {}
    try: return jsonify(run_agent(d.get("patient",{}), d.get("section","full")))
    except Exception as e: return jsonify({"error":str(e)}),500

if __name__ == "__main__":
    print("\n"+"="*52)
    print("  🏥  eHospital Discharge Risk Assessment")
    print("  Open: http://localhost:8000")
    print("="*52+"\n")
    app.run(debug=True, port=8000)
